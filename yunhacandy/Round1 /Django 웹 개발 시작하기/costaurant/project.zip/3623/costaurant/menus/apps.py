from django.apps import AppConfig


class MenusConfig(AppConfig):
    name = 'menus'
